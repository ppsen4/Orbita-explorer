# Órbita — Explorador do Sistema Solar

Aplicação web em React e TypeScript para explorar corpos celestes da API Le Système Solaire e manter um caderno pessoal de observações persistido no Firestore.

## Firebase dedicado

O projeto Firebase `orbita-integrador` foi criado no plano Spark, sem vincular faturamento, ativar Google Analytics ou Gemini. O projeto Firebase anterior fornecido pelo usuário não foi alterado. O app Web `orbita-web` conecta a interface ao Firestore.

O app usa login anônimo do Firebase Authentication e grava em `users/{uid}/observations`. O provedor anônimo está habilitado e as regras de segurança ficam em [`firestore.rules`](./firestore.rules). Elas permitem a cada sessão anônima acessar somente seu próprio caderno e validam campos, limites de tamanho e timestamps.

A configuração Web pública do Firebase dedicado está definida como fallback em `src/firebaseConfig.ts`. Se necessário, `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID` e `VITE_FIREBASE_APP_ID` podem sobrescrever esses valores. A chave Web é pública por definição; as regras do Firestore e a autenticação, não a ocultação da chave, protegem os dados.

## API pública e arquitetura híbrida

A interface consulta `/api/bodies`. O endpoint server-side `api/bodies.ts` usa o token Bearer UUID gratuito exigido pela API Le Système Solaire. Essa credencial permanece na variável server-side `SOLAR_API_TOKEN` e nunca é enviada ao navegador nem incorporada ao bundle.

No domínio Vercel, o frontend usa a rota relativa `/api/bodies`. No GitHub Pages, o build define `VITE_SOLAR_API_BASE_URL` para a origem pública do projeto Vercel; a função Vercel permite CORS somente para `https://ppsen4.github.io`. O token precisa ser cadastrado nas variáveis de ambiente **Production** do projeto Vercel.

## Desenvolvimento local

```bash
cp .env.example .env.local
# Preencha SOLAR_API_TOKEN. VITE_FIREBASE_* são opcionais; há configuração pública padrão.
pnpm install
pnpm dev
```

O Vite encaminha `/api/bodies` ao proxy local em desenvolvimento. No deploy Vercel, `api/bodies.ts` é a função serverless correspondente.

## GitHub Pages

O repositório público `ppsen4/Orbita-explorer` mantém o código-fonte dentro do arquivo `orbita-drop.zip`. O workflow [`.github/workflows/deploy-pages.yml`](./.github/workflows/deploy-pages.yml) extrai esse arquivo, instala dependências, compila o frontend com `base=/Orbita-explorer/` e publica `app/dist` por GitHub Actions. Em **Settings → Pages**, a origem de publicação deve ser **GitHub Actions**.

O workflow configura `VITE_SOLAR_API_BASE_URL` para `https://orbita-explorador.vercel.app`. A origem do frontend precisa continuar em `https://ppsen4.github.io` para corresponder à política CORS do endpoint.

## Vercel

O projeto Vercel precisa conter a aplicação, a função `api/bodies.ts` e o arquivo `vercel.json`. O manifesto configura o build Vite, a SPA e a função serverless. Cadastre `SOLAR_API_TOKEN` em **Project Settings → Environment Variables** para o ambiente Production. Não inclua `.env.local` ou qualquer segredo no repositório, no ZIP ou em variáveis `VITE_*`.

## API e fontes

A [documentação oficial da API Le Système Solaire](https://api.le-systeme-solaire.net/en/) informa que as chamadas a `/rest/bodies/` exigem um Bearer UUID gratuito. A chave é solicitada em [Get API key](https://api.le-systeme-solaire.net/generatekey.html).

A [documentação Vercel Drop](https://vercel.com/docs/drop) descreve o envio de arquivos ou ZIP para publicação sem Git ou CLI. O arquivo `vercel.json` deste projeto declara o build, a SPA e a função `/api/bodies`.
