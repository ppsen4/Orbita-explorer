# Evidências de implantação — Órbita

Atualizado em 2026-11-03.

## GitHub Pages

- Configurações Pages: https://github.com/ppsen4/Orbita-explorer/settings/pages
- Página pública observada: https://ppsen4.github.io/Orbita-explorer/ — retornou `404 File not found`.
- Histórico Actions: https://github.com/ppsen4/Orbita-explorer/actions — o workflow `pages-build-deployment` terminou com sucesso, mas publicou o conteúdo existente sem compilar o ZIP.
- Raiz da branch `main`: https://github.com/ppsen4/Orbita-explorer/tree/main — contém `orbita-drop.zip`, não `index.html`.
- O arquivo ZIP público contém `index.html`, fontes Vite/React, `api/bodies.ts`, `server/solarProxy.ts`, `package.json`, `pnpm-lock.yaml` e `vercel.json`. A correção requer descompactar e compilar via GitHub Actions; os arquivos do ZIP não são servidos automaticamente pelo Pages.

## Vercel

- Projeto: https://vercel.com/sla-d3e4/orbita-explorador
- Domínio de produção: https://orbita-explorador.vercel.app/
- O painel mostrou a implantação Production como `Ready`. A função ainda requer `SOLAR_API_TOKEN` configurado como variável server-side para retornar dados solares.
- O frontend Pages chama o endpoint público `https://orbita-explorador.vercel.app/api/bodies`; a função permite CORS somente para `https://ppsen4.github.io`.

Nenhuma chave ou token é armazenada neste arquivo.
