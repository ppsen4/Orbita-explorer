import type { SolarBodiesResponse } from '../types';

export async function loadBodies(): Promise<SolarBodiesResponse> {
  const apiBaseUrl = (import.meta.env.VITE_SOLAR_API_BASE_URL || '').replace(/\/+$/, '');
  const response = await fetch(`${apiBaseUrl}/api/bodies`, { headers: { Accept: 'application/json' } });
  const payload = await response.json().catch(() => ({})) as SolarBodiesResponse;
  if (!response.ok) {
    throw new Error(payload.error || `Falha ao consultar os corpos celestes (HTTP ${response.status}).`);
  }
  if (!Array.isArray(payload.bodies)) {
    throw new Error('A API respondeu em um formato inesperado.');
  }
  return payload;
}
