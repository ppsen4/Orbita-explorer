# TODO — Órbita: Explorador do Sistema Solar

## Funcionalidade da aplicação
- [x] O sistema deverá consumir dados reais de corpos celestes da API pública e gratuita Le Système Solaire e exibir essas informações na interface.
- [x] A interface deverá tratar carregamento, ausência de dados e erros da API pública.
- [x] C — Cadastrar: permitir inserir registros pessoais por formulário, associados a corpos celestes obtidos pela API.
- [x] R — Consultar: listar no Firestore os registros pessoais salvos pelo observador.
- [x] U — Atualizar: permitir editar registros existentes com formulário preenchido pelos dados atuais.
- [x] D — Excluir: permitir remover registros do Firestore com confirmação.
- [x] Todos os registros CRUD deverão persistir no Firebase/Firestore e ficar isolados por sessão autenticada.
- [x] A interface deverá tratar carregamento, ausência de dados e erros do Firestore.
- [x] A interface web deverá ser responsiva em computadores e dispositivos móveis.

## Publicação híbrida solicitada
- [ ] GitHub Pages deverá compilar o conteúdo de `orbita-drop.zip` e servir os arquivos estáticos do app no caminho do projeto `https://ppsen4.github.io/Orbita-explorer/`.
- [ ] O frontend publicado no GitHub Pages deverá chamar a API solar servida por uma função serverless Vercel, usando uma URL de API configurável e o prefixo correto do projeto.
- [ ] A função Vercel `/api/bodies` deverá aceitar a origem pública GitHub Pages com CORS apropriado e manter `SOLAR_API_TOKEN` exclusivamente no ambiente server-side.
- [ ] O CRUD do Firebase/Firestore deverá continuar funcional no frontend publicado, sujeito às regras e à autenticação já configuradas no projeto Firebase dedicado.
- [ ] A aplicação completa deverá estar publicada em projeto Vercel com domínio público `.vercel.app`, incluindo a função serverless necessária.

> A publicação do GitHub Pages existente retorna 404 porque a branch `main` contém apenas o arquivo ZIP, não um `index.html` extraído na raiz. Nenhuma alteração de publicação híbrida foi confirmada ainda.
