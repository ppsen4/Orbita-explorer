# TODO — Órbita: Explorador do Sistema Solar

## Exploração da API pública
- [ ] O sistema deve consumir dados reais de corpos celestes da API pública e gratuita Le Système Solaire em `https://api.le-systeme-solaire.net/rest` e exibir esses dados na interface.
- [ ] A interface deve tratar visualmente carregamento, ausência de dados e erros da API pública.

## CRUD de registros pessoais no Firebase/Firestore
- [ ] O sistema deve permitir cadastrar registros pessoais por formulário e relacioná-los a corpos celestes obtidos pela API.
- [ ] O sistema deve consultar e listar os registros pessoais salvos pelo usuário no Firestore.
- [ ] O sistema deve exibir os detalhes de cada registro, incluindo os dados associados do corpo celeste.
- [ ] O sistema deve permitir editar registros pessoais existentes por formulário preenchido com os dados atuais.
- [ ] O sistema deve permitir excluir registros pessoais com confirmação para evitar remoções acidentais.
- [ ] Todos os registros do CRUD devem persistir no Firebase/Firestore.
- [ ] A interface deve tratar visualmente carregamento, ausência de dados e erros do Firestore.

## Interface responsiva e publicação
- [ ] A interface web deve ser responsiva para uso em computadores e dispositivos móveis.
- [ ] A aplicação final deve estar configurada e publicada na Vercel, com endereço público terminado em `.vercel.app`.
